using System.ComponentModel.DataAnnotations;

namespace UserManagementAPI.Services;

public static class UserValidation
{
    public static Dictionary<string, string[]> Validate<T>(T request) where T : class
    {
        var context = new ValidationContext(request);
        var results = new List<ValidationResult>();
        var isValid = Validator.TryValidateObject(request, context, results, validateAllProperties: true);

        if (isValid)
            return new Dictionary<string, string[]>();

        return results
            .SelectMany(result => result.MemberNames.DefaultIfEmpty("Request")
                .Select(member => new { Member = member, Error = result.ErrorMessage ?? "Invalid value." }))
            .GroupBy(item => item.Member)
            .ToDictionary(group => group.Key, group => group.Select(item => item.Error).ToArray());
    }
}
