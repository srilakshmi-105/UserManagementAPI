using System.Collections.Concurrent;
using UserManagementAPI.Models;

namespace UserManagementAPI.Services;

public class UserService
{
    private readonly ConcurrentDictionary<int, User> _users = new();
    private int _nextId = 0;

    public UserService()
    {
        Create(new CreateUserRequest { Name = "Alex Johnson", Email = "alex@example.com", Age = 21 });
        Create(new CreateUserRequest { Name = "Sam Taylor", Email = "sam@example.com", Age = 22 });
    }

    public List<User> GetAll() =>
        _users.Values.OrderBy(user => user.Id).ToList();

    public User? GetById(int id) =>
        _users.TryGetValue(id, out var user) ? user : null;

    public User Create(CreateUserRequest request)
    {
        var user = new User
        {
            Id = Interlocked.Increment(ref _nextId),
            Name = request.Name.Trim(),
            Email = request.Email.Trim().ToLowerInvariant(),
            Age = request.Age
        };

        _users[user.Id] = user;
        return user;
    }

    public User? Update(int id, UpdateUserRequest request)
    {
        if (!_users.ContainsKey(id))
            return null;

        var updatedUser = new User
        {
            Id = id,
            Name = request.Name.Trim(),
            Email = request.Email.Trim().ToLowerInvariant(),
            Age = request.Age
        };

        _users[id] = updatedUser;
        return updatedUser;
    }

    public bool Delete(int id) =>
        _users.TryRemove(id, out _);

    public bool EmailExists(string email, int? exceptUserId = null)
    {
        var normalizedEmail = email.Trim();
        return _users.Values.Any(user =>
            user.Email.Equals(normalizedEmail, StringComparison.OrdinalIgnoreCase)
            && user.Id != exceptUserId);
    }
}
